
# CNotes

Console notepad writed on Java

## Commands

```
1. new - create new note
2. all - see all notes
3. delete - delete note
4. help - see all commands
5. quit - quit from app
6. read - read note
```
