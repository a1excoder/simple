# noSpyTraffic

<hr>
<h3>PHP script for mixing traffic</h3>

<h5>How use this script</h5>

```
php main.php
```

P.S. do not forget update the list of sites in the sites.json file

if you use linux:
```
sudo apt-get install php-curl
```
