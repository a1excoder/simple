# confman
Simple config file parser
<hr>
<h4>This is my first +/- real project writed on C and works through ass)))</h4>

<p>build parser</p>

```bash
cd confman/
make buildlib
make buildmain
```

<p>testing parser</p>

```bash
cd example/
./main first.conf
```
