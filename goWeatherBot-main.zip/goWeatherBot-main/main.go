package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api"
)

type StrArray []string

type Token struct {
	telegram       string
	openweathermap string
}

type WeatherData struct {
	Weather []Weather
	Main    mainWeather
	Wind    wind
	Sys     sys
	Name    string
	Cod     int
	Message string
}

type Weather struct {
	Description string `json:"description"`
}

type mainWeather struct {
	Temp     float32
	Temp_min float32
	Temp_max float32
}

type wind struct {
	Speed float32
}

type sys struct {
	Country string
}

func ReplyToMessage(update tgbotapi.Update, bot *tgbotapi.BotAPI, message string) {
	msg := tgbotapi.NewMessage(update.Message.Chat.ID, message)
	msg.ReplyToMessageID = update.Message.MessageID
	bot.Send(msg)
}

func SendMessage(update tgbotapi.Update, bot *tgbotapi.BotAPI, message string) {
	msg := tgbotapi.NewMessage(update.Message.Chat.ID, message)
	bot.Send(msg)
}

func (arr StrArray) GreetingsCheck(message string) bool {
	for _, str := range arr {
		if str == message || strings.ToLower(str) == message ||
			strings.ToUpper(str) == message {
			return true
		}
	}
	return false
}

func ResponceCheck(resp *http.Response) string {
	var result string
	var data WeatherData

	buff, _ := ioutil.ReadAll(resp.Body)
	json.Unmarshal(buff, &data)

	if data.Cod != 200 {
		return data.Message
	}

	result = fmt.Sprintf("name: %s\ncountry: %s\ntemp: %.3f\ndescription: %s\nmin temp: %.3f\nmax temp %.3f\nwind speed: %.3f",
		data.Name, data.Sys.Country, data.Main.Temp, data.Weather[0].Description, data.Main.Temp_min, data.Main.Temp_max, data.Wind.Speed)
	return result
}

var Greetings = StrArray{
	"Hello", "Hi", "Good Morning",
	"Hola", "Привет", "Привіт"}

var token = Token{
	"---telegram-token---",
	"---openweathermap-token---"}

var request string = "https://api.openweathermap.org/data/2.5/weather?units=metric&lang=en&q="

func main() {

	bot, err := tgbotapi.NewBotAPI(token.telegram)
	if err != nil {
		panic(err)
	}

	bot.Debug = false

	u := tgbotapi.NewUpdate(0)
	u.Timeout = 60

	updates, err := bot.GetUpdatesChan(u)

	for update := range updates {

		if update.Message == nil {
			continue
		}

		if update.Message.CommandWithAt() == "start" {
			SendMessage(update, bot, "Hi, i`am weather bot, i was created for viewing weather!")
			continue
		}

		if update.Message.CommandWithAt() == "weather" {
			if ArgBuff := update.Message.CommandArguments(); ArgBuff != "" {

				resp, err := http.Get(request + ArgBuff + "&APPID=" + token.openweathermap)
				if err != nil {
					SendMessage(update, bot, err.Error())
				}

				ReplyToMessage(update, bot, ResponceCheck(resp))
				resp.Body.Close()
				continue
			}

			ReplyToMessage(update, bot, "after \"/weather\" enter name of city or town")
			continue
		}

		if Greetings.GreetingsCheck(update.Message.Text) {
			ReplyToMessage(update, bot, "hi")
			continue
		}

		SendMessage(update, bot, "command not found.")

	}
}
