# goWeatherBot
Simple telegram bot for view weather

### build project

#### First of all, you must register the tokens in the structure of the main.go file
``` go
var token = Token{
	"---telegram-token---",
	"---openweathermap-token---"}
```

#### build and run project
```bash
go build
./main
```

### how does it look
![image](https://raw.githubusercontent.com/a1excoder/goWeatherBot/main/image1.png)
