# a1excode_parser
My site parser for demonstration

### result works script:
```
title: Книги по языку C
	query: Друзья сегодня хотел бы посоветовать книги по языку C или же СИ которые я читал и другиеPS. все книги есть в нашем телеграм канале Книги для ITшников1. Пол Дейт
		url: https://a1excode.netxisp.host/post/10

title: Мои программы
	query: Это список программного обеспечения написанного мной, он совремерем будет пополняться.Некоторые программы с открытым исходным кодом а некоторые нет!Языки программирования
		url: https://a1excode.netxisp.host/post/9

title: Настройка ngrok на Windows
	query: Сегодня я вас научу запускать ваш сайт из localhost в интернет с помощью ngrok на Windows:Для начала давайте скачаем ngrok: скачатьРаспаковываем архив с прогой и перетаск
		url: https://a1excode.netxisp.host/post/8

title: Шифровальщик GoodCrypt
	query: Всем привет, я тут написал прогу для шифрования файлов AES алгоритмом, прогу я назвал GoodCrypt, код самой проги у меня на Github аккаунте, ее я написал на языке Python, 
		url: https://a1excode.netxisp.host/post/7

title: Парсинг сайтов на Python
	query: Друзья сегодня я вас научу парсить данные с сайтов и выводить их в терминал и все это на Python:для начала установим две библиотеки beautifulsoup4 и&n
		url: https://a1excode.netxisp.host/post/6

title: Как поднять FTP на Linux сервере
	query: Для начала откроем терминал под рутом:sudo su -Теперь давайте обновим все пакеты:apt-get updateapt-get upgradeДальше установим vsftpd для поднятия ftp сервера:apt-get ins
		url: https://a1excode.netxisp.host/post/5

```
