from Parser import Parser


if __name__ == '__main__':
    parser = Parser()
    parser.view_list_last_six_news()
